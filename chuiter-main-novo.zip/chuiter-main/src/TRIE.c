#include  "../include/TRIE.h"
#include  "../include/AVL.h"

TrieNode *cNode() {
    TrieNode *newNode = (TrieNode*)malloc(sizeof(*newNode));

    for(int i = 0; i < MAX_LINHA; i++)
        newNode->children[i] = NULL;

    newNode->end = false;
    return newNode;
}

bool insTrie(TrieNode **root, char *sigText) {
    if(*root == NULL)
        *root = cNode();

    unsigned char *text = (unsigned char *)sigText;
    TrieNode *tmp = *root;
    int length = strlen(sigText);

    for(int i = 0; i < length; i++) {
        if(tmp->children[text[i]] == NULL)
            tmp->children[text[i]] = cNode();
        
        tmp = tmp->children[text[i]];
    }

    if(tmp->end)
        return false;
    else {
        tmp->end = true;
        return true;
    }
}

void recPrint(TrieNode *node, unsigned char *pref, int length) {
    unsigned char newPref[length + 2];
    memcpy(newPref, pref, length);
    newPref[length + 1] = 0;

    if(node->end)
        printf("WORD: %s\n", pref);

    for(int i = 0; i < MAX_LINHA; i++)
        if(node->children[i] != NULL) {
            newPref[length] = i;
            recPrint(node->children[i], newPref, (length+1));
        }
}

void printTrie(TrieNode *root) {
    if(root == NULL) {
        printf("EMPTY TRIE\n");
        return;
    }
}

bool searchTrie(TrieNode *root, char *sigText) {
    unsigned char * text = (unsigned char *)sigText;
    int length = strlen(sigText);
    TrieNode *tmp = root;

    for(int i = 0; i < length; i++) {
        if(tmp->children[text[i]] == NULL)
            return false;
        
        tmp = tmp->children[text[i]];
    }
    return tmp->end;
}

TrieNode *create_node_trie(){  //criaçao do nó na arvore trie
    TrieNode *node = (TrieNode*)malloc(sizeof(TrieNode));
    if(node){
        node->end = false;
        for(int i = 0;i<ASCII_SIZE;i++){
            node->children[i] = NULL;
        }
        node->root_avl = NULL;
        return node;
    }
    return NULL;
} 

void insert_trie(TrieNode *root, const char *name, int key,char *chuiter){//inserção na arvore
    TrieNode *current = root;
    for(int i=0; name[i] != '\0';i++){
        int index = name[i] - 'a';
        if(!current->children[index]){
            current->children[index] = create_node_trie();
        }
        current = current->children[index];
    }
    // if(current->end == true){ //nova mensagem do usuario já existente
        current->root_avl = insert_avl(current->root_avl, key, chuiter);
    // }else{ //primeira inserção do usuario
        current->end = true;
//        current->root_avl = create_node_avl(key, chuiter);
  //  }
}

TrieNode *search_trie(TrieNode *root, const char *name) {
    TrieNode *current = root;
    for (int i = 0; name[i] != '\0'; i++) {
        printf("%d_",(name[i] - 'a')); //teste de execução
        int index = name[i] - 'a';
        if (!current->children[index]) {
            return NULL; // Palavra não encontrada
        }
        current = current->children[index];
    }
    if(current != NULL && current->end)
        return current;
    return NULL;
}

bool hasChildren(TrieNode *node) {
    if(node == NULL)
        return false;
    
    for(int i = 0; i < MAX_LINHA; i++)
        if(node->children[i] != NULL)//possui pelo menos um filho
            return true;

    return false;
}

TrieNode* recDelete(TrieNode *node, unsigned char *name, bool *deleted) {
    if(node == NULL)
        return node;
    
    if(*name == '\0') {
        if(node->end) {
            node->end = false;
            *deleted = true;

            if(hasChildren(node) == false) {
                free(node);
                node = NULL;
            }
        }
        return node;
    }

    node->children[name[0]] = recDelete(node->children[name[0]], name+1, deleted);
    if(*deleted && hasChildren == false &&node->end == false) {
        free(node);
        node = NULL;
    }
    return node;
}

bool delete_key(TrieNode **root, const char *sName) {
    unsigned char *name = (unsigned char *)sName;
    bool result = false;

    if(*root == NULL)
        return false;

    *root = recDelete(*root, name, &result);
    return result;
}