#ifndef TRIE_H
#define TRIE_H
#define ASCII_SIZE 26

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "AVL.h"

typedef struct TrieNode{
    bool end;
    struct TrieNode *children[ASCII_SIZE];
    AVLNode *root_avl;
}TrieNode;

TrieNode *cNode();
bool insTrie(TrieNode **root, char *sigText);
void printTrie(TrieNode *root);
void recprint(TrieNode *node, unsigned char *pref, int length);
bool searchTrie(TrieNode *root, char *sigText);

TrieNode *create_node_trie();                       //cria um nó
void insert_trie(TrieNode *root, const char *name,int key, char *chuiter);  //inserir um nó 
TrieNode *search_trie(TrieNode *root, const char *name); //busca de usuario
bool delete_key(TrieNode **root, const char *sName);  //deleta uma palavra

TrieNode* recDelete(TrieNode *node, unsigned char *name, bool *deleted);
bool hasChildren(TrieNode *node);
//void free_trie(TrieNode *root);                     //libera o espaço de memoria


#endif