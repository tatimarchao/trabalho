Trabalho realizado por Allef G. 
Para a diciplina de estrutura de dados, 
onde é abordado o estudo das arvores AVL e TRIE.


